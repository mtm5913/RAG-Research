Fieldlight comparison reproduction

Contents: an allowlisted copy of the scripts and source-derived paraphrase manifest used for the comparisons. No keys, environment files, server secrets or session tokens are included.

From this directory:
1. python3 scripts/compare-retrieval.py
   Local exact-token baseline; no network or dependencies.
2. python3 scripts/run-retrieval-comparison.py
   Sends seven ordinary questions through the public Fieldlight app, spaced by 22 seconds. Requires the hosted app to remain available and unchanged. Writes docs/public/retrieval-comparison.json. No provider key required. Public quotas apply. This rerun consumes inference requests and is not necessary merely to read the included evidence downloads.
3. Create a separate virtual environment; install tokenizers==0.23.3 from PyPI. Download only tokenizer.json from:
   https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/1110a243fdf4706b3f48f1d95db1a4f5529b4d41/tokenizer.json
   Then run:
   python scripts/compare-chunking.py --tokenizer /absolute/path/tokenizer.json

Chunking comparison is structural only; it does not reimport or benchmark alternative vector indexes. The manifest includes prose-only reuse assessments and original source URLs. AI-prepared paraphrases and project notes are distinguished in the live pipeline. Model tokenizer configuration is Apache-2.0; consult the model card for its license and limitations. The tokenizer file itself is not bundled.

The run script creates the output directory when needed. Compare hashes/configuration before treating a later rerun as the same experiment. The small purpose-selected question set does not establish general reliability or a statistically significant advantage.
